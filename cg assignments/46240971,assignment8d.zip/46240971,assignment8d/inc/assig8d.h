#include <algorithm>
#include <iostream>
#include <list>
#include <string>
#include <sstream>

using namespace std;
